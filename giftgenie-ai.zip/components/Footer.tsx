import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full text-center py-4 mt-auto">
      <p className="text-base text-purple-700 drop-shadow-sm">
        Powered by AI magic ✨ &mdash; Created with fun.
      </p>
    </footer>
  );
};