import React from 'react';
import type { GiftIdea } from '../types';
import { GiftCard } from './GiftCard';
import { Loader } from './Loader';

interface GiftIdeasDisplayProps {
  ideas: GiftIdea[];
  isLoading: boolean;
  error: string | null;
}

export const GiftIdeasDisplay: React.FC<GiftIdeasDisplayProps> = ({ ideas, isLoading, error }) => {
  if (isLoading) {
    return (
      <div className="w-full text-center py-16">
        <Loader />
        <p className="text-purple-800 text-xl mt-4 drop-shadow-sm">The Genie is thinking...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full text-center py-16 bg-red-200/50 p-6 rounded-xl border-2 border-red-300">
        <p className="text-red-800 font-bold text-xl drop-shadow-sm">Oops! Something went wrong.</p>
        <p className="text-red-700 mt-2 text-base">{error}</p>
      </div>
    );
  }

  if (ideas.length === 0) {
    return (
      <div className="w-full text-center py-16">
        <p className="text-purple-900 text-3xl font-bold drop-shadow-md">✨ Ready to find the perfect gift? ✨</p>
        <p className="text-purple-700 mt-2 text-lg">Fill out the form above to get started!</p>
      </div>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto py-12">
      <h2 className="font-display text-4xl text-center text-purple-900 mb-8 drop-shadow-[0_2px_2px_rgba(0,0,0,0.2)]">
        Your Wishlist!
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {ideas.map((idea, index) => (
          <GiftCard key={index} idea={idea} />
        ))}
      </div>
    </div>
  );
};