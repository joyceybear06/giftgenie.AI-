import React from 'react';
import type { GiftIdea } from '../types';

interface GiftCardProps {
  idea: GiftIdea;
}

const GiftTypeBadge: React.FC<{ type: GiftIdea['type'] }> = ({ type }) => {
  if (type === 'Product') {
    return null;
  }

  const badgeStyles = {
    DIY: 'bg-blue-500 border-blue-600',
    Custom: 'bg-green-500 border-green-600',
    Product: '', // Not used, but good for completeness
  };

  return (
    <div className={`absolute top-3 right-3 px-2.5 py-1 text-xs font-bold text-white rounded-full border-2 ${badgeStyles[type]} shadow-md z-10`}>
      {type}
    </div>
  );
};


export const GiftCard: React.FC<GiftCardProps> = ({ idea }) => {
  const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(idea.searchQuery)}`;

  return (
    <a
      href={searchUrl}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`Search for ${idea.name}`}
      className="relative bg-white/30 backdrop-blur-sm border-2 border-white/40 p-6 rounded-2xl shadow-lg flex flex-col h-full transform hover:scale-105 hover:shadow-2xl transition-all duration-300 focus:outline-none focus:ring-4 focus:ring-pink-400 focus:ring-opacity-75 group"
    >
      <GiftTypeBadge type={idea.type} />
      <h3 className="text-2xl font-bold text-purple-900 drop-shadow-sm group-hover:text-pink-700 transition-colors duration-300 pr-12">{idea.name}</h3>
      <p className="text-purple-800 mt-2 flex-grow text-base">{idea.description}</p>
      <div className="mt-4 pt-4 border-t-2 border-white/50">
        <p className="text-base font-semibold text-pink-800">Why it's a great fit:</p>
        <p className="text-base text-purple-700 italic mt-1">"{idea.why}"</p>
      </div>
    </a>
  );
};