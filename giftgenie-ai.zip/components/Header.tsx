import React from 'react';

const SparkleIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 3L9.5 8.5L4 11L9.5 13.5L12 19L14.5 13.5L20 11L14.5 8.5L12 3z" />
        <path d="M5 3v4" />
        <path d="M19 17v4" />
    </svg>
);


export const Header: React.FC = () => {
  return (
    <header className="w-full text-center py-6 md:py-8">
      <div className="flex items-center justify-center gap-4">
        <SparkleIcon className="text-purple-400 w-8 h-8 transform -rotate-12" />
        <h1 className="font-display text-3xl md:text-5xl text-purple-900 drop-shadow-[0_2px_2px_rgba(0,0,0,0.2)]">
          GiftGenie AI
        </h1>
        <SparkleIcon className="text-pink-400 w-8 h-8 transform rotate-12" />
      </div>
      <p className="mt-4 text-purple-800 text-base md:text-lg drop-shadow-sm">
        Your wish for the perfect gift is my command!
      </p>
    </header>
  );
};