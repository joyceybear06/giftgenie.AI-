import React, { useState } from 'react';
import { GiftTone, BudgetRange } from '../types';
import type { FormState } from '../types';

interface GiftFormProps {
  onSubmit: (formData: FormState) => void;
  isLoading: boolean;
}

const holidays = [
  // Common Personal
  "Birthday",
  "Anniversary",
  // US Federal & Common
  "Valentine's Day",
  "Mother's Day",
  "Father's Day",
  "New Year's Day",
  "Thanksgiving",
  "Juneteenth",
  "Independence Day (4th of July)",
  // Religious & Cultural
  "Christmas",
  "Easter",
  "Hanukkah",
  "Passover",
  "Eid al-Fitr",
  "Eid al-Adha",
  "Diwali",
  "Vesak (Buddha's Birthday)",
  // Other Events
  "Graduation",
  "Housewarming",
  "Get Well Soon",
  "Just Because",
];


const ToneSelector: React.FC<{ selected: GiftTone; onChange: (tone: GiftTone) => void }> = ({ selected, onChange }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {Object.values(GiftTone).map((tone) => (
        <button
          key={tone}
          type="button"
          onClick={() => onChange(tone)}
          className={`py-2 px-1 text-center font-semibold rounded-lg border-2 transition-all duration-200 text-base ${
            selected === tone
              ? 'bg-pink-500 border-pink-600 text-white scale-105 shadow-lg'
              : 'bg-white/50 border-white/60 hover:bg-white/80 text-purple-800'
          }`}
        >
          {tone}
        </button>
      ))}
    </div>
  );
};

const BudgetSelector: React.FC<{ selected: BudgetRange; onChange: (budget: BudgetRange) => void }> = ({ selected, onChange }) => {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
      {Object.values(BudgetRange).map((budget) => (
        <button
          key={budget}
          type="button"
          onClick={() => onChange(budget)}
          className={`py-2 px-1 text-center font-semibold rounded-lg border-2 transition-all duration-200 text-sm ${
            selected === budget
              ? 'bg-purple-500 border-purple-600 text-white scale-105 shadow-lg'
              : 'bg-white/50 border-white/60 hover:bg-white/80 text-purple-800'
          }`}
        >
          {budget}
        </button>
      ))}
    </div>
  );
};

export const GiftForm: React.FC<GiftFormProps> = ({ onSubmit, isLoading }) => {
  const [formData, setFormData] = useState<FormState>({
    recipient: '',
    age: '',
    occasion: '',
    hobbies: '',
    vibe: '',
    tone: GiftTone.FUNNY,
    budget: BudgetRange.ANY,
  });
  const [occasionType, setOccasionType] = useState<'custom' | 'holiday'>('custom');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleToneChange = (tone: GiftTone) => {
    setFormData((prev) => ({ ...prev, tone }));
  };

  const handleBudgetChange = (budget: BudgetRange) => {
    setFormData((prev) => ({ ...prev, budget }));
  };
  
  const handleOccasionTypeChange = (type: 'custom' | 'holiday') => {
    setOccasionType(type);
    // Clear the occasion when switching types to prevent carrying over values
    setFormData(prev => ({ ...prev, occasion: '' }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const commonInputClasses = "w-full p-3 rounded-lg border-2 border-white/60 bg-white/50 focus:bg-white/80 focus:border-pink-400 focus:outline-none focus:ring-2 focus:ring-pink-400 transition-all placeholder-purple-500 shadow-inner text-base text-purple-900";

  return (
    <div className="w-full max-w-2xl mx-auto bg-white/30 backdrop-blur-md p-6 sm:p-8 rounded-2xl shadow-2xl border-2 border-white/40">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="recipient" className="block text-purple-900 font-bold mb-2 drop-shadow-sm text-lg">Recipient's Name (optional)</label>
            <input type="text" id="recipient" name="recipient" value={formData.recipient} onChange={handleChange} placeholder="e.g., Mom, Alex, my boss" className={commonInputClasses} />
          </div>
          <div>
            <label htmlFor="age" className="block text-purple-900 font-bold mb-2 drop-shadow-sm text-lg">Age (optional)</label>
            <input type="text" id="age" name="age" value={formData.age} onChange={handleChange} placeholder="e.g., 30s, 5, 'ageless'" className={commonInputClasses} />
          </div>
        </div>

        <div>
            <label className="block text-purple-900 font-bold mb-2 drop-shadow-sm text-lg">Occasion</label>
            <div className="flex gap-2 mb-3">
                 {([ 'custom', 'holiday'] as const).map(type => (
                    <button
                        key={type}
                        type="button"
                        onClick={() => handleOccasionTypeChange(type)}
                        className={`capitalize w-full py-2 px-4 font-semibold rounded-md border-2 transition-all duration-200 text-sm ${
                            occasionType === type
                                ? 'bg-purple-500 border-purple-600 text-white shadow-md'
                                : 'bg-white/50 border-white/60 hover:bg-white/80 text-purple-700'
                        }`}
                    >
                        {type}
                    </button>
                 ))}
            </div>
            {occasionType === 'holiday' ? (
                 <select
                    id="occasion"
                    name="occasion"
                    value={formData.occasion}
                    onChange={handleChange}
                    required
                    className={commonInputClasses}
                >
                    <option value="" disabled>Select a holiday...</option>
                    {holidays.map(h => <option key={h} value={h}>{h}</option>)}
                </select>
            ) : (
                <input type="text" id="occasion" name="occasion" value={formData.occasion} onChange={handleChange} placeholder="e.g., Birthday, Anniversary" required className={commonInputClasses} />
            )}
        </div>
        <div>
            <label htmlFor="vibe" className="block text-purple-900 font-bold mb-2 drop-shadow-sm text-lg">Recipient's Personality / Vibe</label>
            <textarea id="vibe" name="vibe" value={formData.vibe} onChange={handleChange} placeholder="e.g., Loves nerdy stuff, minimalist, life of the party, homebody" required className={`${commonInputClasses} h-24`}></textarea>
        </div>
        <div>
            <label htmlFor="hobbies" className="block text-purple-900 font-bold mb-2 drop-shadow-sm text-lg">Hobbies & Interests</label>
            <textarea id="hobbies" name="hobbies" value={formData.hobbies} onChange={handleChange} placeholder="e.g., hiking, video games, knitting, trying new restaurants" required className={`${commonInputClasses} h-24`}></textarea>
        </div>

        <div>
            <label className="block text-purple-900 font-bold mb-2 drop-shadow-sm text-lg">Budget</label>
            <BudgetSelector selected={formData.budget} onChange={handleBudgetChange} />
        </div>
        
        <div>
            <label className="block text-purple-900 font-bold mb-2 drop-shadow-sm text-lg">Gift Tone</label>
            <ToneSelector selected={formData.tone} onChange={handleToneChange} />
        </div>

        <button 
          type="submit" 
          disabled={isLoading}
          className="w-full py-4 px-6 font-bold text-xl text-white bg-pink-500 rounded-xl border-b-4 border-pink-700 hover:bg-pink-400 hover:border-pink-600 active:border-b-2 active:translate-y-0.5 transition-all duration-150 ease-in-out disabled:bg-gray-400 disabled:cursor-not-allowed disabled:border-gray-500 shadow-lg"
        >
          {isLoading ? 'Consulting the Cosmos...' : 'Summon the Genie'}
        </button>
      </form>
    </div>
  );
};