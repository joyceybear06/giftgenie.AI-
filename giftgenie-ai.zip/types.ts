export enum GiftTone {
  FUNNY = 'Funny',
  BOUGIE = 'Bougie',
  SENTIMENTAL = 'Sentimental',
  PRACTICAL = 'Practical',
  CREATIVE = 'Creative',
  GRIEF = 'Grief',
  DIY = 'DIY',
  UNIQUE = 'Unique',
}

export enum BudgetRange {
  UNDER_25 = 'Under $25',
  RANGE_25_100 = '$25 - $100',
  RANGE_100_250 = '$100 - $250',
  OVER_250 = '$250+',
  ANY = 'Any',
}

export type GiftType = 'Product' | 'Custom' | 'DIY';

export interface GiftIdea {
  name: string;
  description: string;
  why: string;
  searchQuery: string;
  type: GiftType;
}

export interface FormState {
  recipient: string;
  age: string;
  occasion: string;
  hobbies: string;
  vibe: string;
  tone: GiftTone;
  budget: BudgetRange;
}