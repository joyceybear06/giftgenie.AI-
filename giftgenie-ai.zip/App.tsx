
import React, { useState, useCallback } from 'react';
import { GiftForm } from './components/GiftForm';
import { GiftIdeasDisplay } from './components/GiftIdeasDisplay';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { generateGiftIdeas } from './services/geminiService';
import type { FormState, GiftIdea } from './types';

const App: React.FC = () => {
  const [giftIdeas, setGiftIdeas] = useState<GiftIdea[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerateIdeas = useCallback(async (formData: FormState) => {
    setIsLoading(true);
    setError(null);
    setGiftIdeas([]);
    try {
      const ideas = await generateGiftIdeas(formData);
      setGiftIdeas(ideas);
    } catch (err) {
      console.error(err);
      setError('Sorry, the Genie is tired! Could not generate gift ideas. Please check your connection or try again later.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <div className="min-h-screen flex flex-col p-4 sm:p-6 lg:p-8">
      <Header />
      <main className="flex-grow flex flex-col items-center justify-center w-full max-w-4xl mx-auto">
        <GiftForm onSubmit={handleGenerateIdeas} isLoading={isLoading} />
        <GiftIdeasDisplay ideas={giftIdeas} isLoading={isLoading} error={error} />
      </main>
      <Footer />
    </div>
  );
};

export default App;
