import { GoogleGenAI, Type } from "@google/genai";
import type { FormState, GiftIdea } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      name: {
        type: Type.STRING,
        description: 'The name of the gift item.'
      },
      description: {
        type: Type.STRING,
        description: 'A brief, compelling description of the gift.'
      },
      why: {
        type: Type.STRING,
        description: 'A short, personalized explanation for why this gift is a great fit for the recipient.'
      },
      searchQuery: {
        type: Type.STRING,
        description: 'An optimized Google search query to find this gift. For DIY/Custom, search for tutorials or services. Example: "custom engraved leather journal".'
      },
      type: {
        type: Type.STRING,
        description: "Classify the gift as 'Product' (can be bought directly), 'Custom' (requires personalization), or 'DIY' (do-it-yourself project)."
      }
    },
    required: ["name", "description", "why", "searchQuery", "type"]
  }
};


export const generateGiftIdeas = async (formData: FormState): Promise<GiftIdea[]> => {
  const { recipient, age, occasion, hobbies, vibe, tone, budget } = formData;

  const prompt = `You are GiftGenie, an expert in finding the perfect, creative gift. Generate 3-5 unique gift ideas.

  **Recipient Details:**
  - **Name:** ${recipient || 'this person'}
  - **Age:** ${age || 'any age'}
  - **Personality/Vibe:** ${vibe}
  - **Hobbies/Interests:** ${hobbies}
  
  **Occasion:** ${occasion}

  **Budget:** The gift ideas should be within the **${budget}** price range. If the tone is 'DIY', the budget applies to materials.
  
  **Desired Tone:** The gift suggestions should have a **${tone}** tone.

  For each gift, provide a name, a brief description, and a short explanation of why it's a great fit.
  
  **CRUCIAL INSTRUCTIONS:**
  1.  **Classify each gift**: For each idea, set a 'type' property. The type must be one of the following strings:
      - **'Product'**: A gift that can be bought off-the-shelf.
      - **'Custom'**: A product that requires personalization (e.g., engraving, custom art).
      - **'DIY'**: A do-it-yourself project that the user will create themselves.
  2.  **Provide a 'searchQuery'**: A concise, effective Google search term. For 'Product' or 'Custom' gifts, this query should help find the item to purchase. For 'DIY' gifts, the query should lead to tutorials or materials lists (e.g., "how to make a scrapbook tutorial").

  Ensure the output is a valid JSON array of objects.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.8,
      },
    });
    
    const jsonText = response.text.trim();
    const ideas: GiftIdea[] = JSON.parse(jsonText);
    return ideas;

  } catch (error) {
    console.error("Error generating gift ideas from Gemini:", error);
    // In case of an API or parsing error, return a more user-friendly error or an empty array.
    throw new Error("Failed to communicate with the AI Genie.");
  }
};